# EMAC

Multi Agent Control Framework.

A framework for quick testing of different control paradigms,
including Centralized, Decentralized and Economic control.